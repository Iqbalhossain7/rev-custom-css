<?php
/**
 * @package Rev Custom css
 */
 
function rev_custom_css_dactivation(){
	
}